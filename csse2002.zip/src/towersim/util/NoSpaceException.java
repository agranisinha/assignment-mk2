package towersim.util;

public class NoSpaceException {

}
