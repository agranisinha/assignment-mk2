package towersim.util;

public interface Tickable {
    public void tick();
    //ticks the time forwards 1 tick.
}
