package towersim.util;

public class NoSuitableGateException {

}
