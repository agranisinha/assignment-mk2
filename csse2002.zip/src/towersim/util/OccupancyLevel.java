package towersim.util;

public interface OccupancyLevel {
    public int calculateOccupancyLevel();
    //returns occupancy level 0 to 100, percent
}
