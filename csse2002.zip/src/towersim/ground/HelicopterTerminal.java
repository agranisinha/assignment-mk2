package towersim.ground;

import towersim.aircraft.AircraftType;

public class HelicopterTerminal extends Terminal {

    public HelicopterTerminal(int terminalNumber) {
        super(terminalNumber);
    }
}
