package towersim.ground;

public class HelicopterTerminal extends Terminal{

    protected HelicopterTerminal(int terminalNumber) {
        super(terminalNumber);
    }
}
