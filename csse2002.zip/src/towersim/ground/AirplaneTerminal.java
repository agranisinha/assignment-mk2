package towersim.ground;

public class AirplaneTerminal extends Terminal{

    protected AirplaneTerminal(int terminalNumber) {
        super(terminalNumber);
    }
}
