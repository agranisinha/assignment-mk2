package towersim.aircraft;

import java.io.*;


public enum AircraftType {

    AIRPLANE,
    HELICOPTER

}
